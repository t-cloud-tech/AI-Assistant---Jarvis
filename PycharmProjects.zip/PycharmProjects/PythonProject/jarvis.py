import os
import re
import requests
import speech_recognition as sr
import webbrowser
import pyautogui
import datetime
import pyttsx3  # offline TTS

# === API KEY (OpenRouter/DeepSeek) ===
API_KEY = "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"
API_URL = "https://openrouter.ai/api/v1/chat/completions"

# === Your Name ===
USER_NAME = "Tirth"

# === Utility: Clean text (remove emojis/symbols + brackets etc.) ===
def clean_text(text):
    text = re.sub(r'[^\x00-\x7F]+', '', text)   # keep only ASCII chars
    text = re.sub(r'\[.*?\]', '', text)         # remove things inside [ ]
    text = text.strip()
    return text

# === Speak function ===
def speak(text):
    text = clean_text(text)
    if not text.strip():
        return
    engine = pyttsx3.init()
    engine.setProperty('rate', 160)
    engine.setProperty('volume', 1.0)

    # Select female voice if available
    voices = engine.getProperty('voices')
    for v in voices:
        if "female" in v.name.lower() or "zira" in v.name.lower():
            engine.setProperty('voice', v.id)
            break

    engine.say(text)
    engine.runAndWait()
    engine.stop()

# === STT Function ===
def listen(lang="en-US"):
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        recognizer.adjust_for_ambient_noise(source)
        audio = recognizer.listen(source)
    try:
        text = recognizer.recognize_google(audio, language=lang)
        return text
    except sr.UnknownValueError:
        print("⚠️ Sorry, I didn't catch that.")
        return ""
    except sr.RequestError as e:
        print(f"⚠️ STT error: {e}")
        return ""

# === Chat Function ===
def chat(prompt):
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json",
        "HTTP-Referer": "http://localhost",
        "X-Title": "Jarvis Assistant"
    }
    data = {
        "model": "deepseek/deepseek-chat",
        "messages": [{"role": "user", "content": prompt}]
    }
    try:
        resp = requests.post(API_URL, headers=headers, json=data, timeout=30)
        resp.raise_for_status()
        reply = resp.json()["choices"][0]["message"]["content"]

        # Personalize greetings
        if "hello" in reply.lower():
            reply = reply.replace("Hello", f"Hello {USER_NAME}").replace("hello", f"hello {USER_NAME}")

        return reply
    except Exception:
        return "Sorry, I cannot connect right now."

# === Tools ===
def tool_open_url(site):
    if not site.startswith("http"):
        site = "https://" + site
    webbrowser.open(site)
    return f"Opening {site}"

def tool_type(text):
    pyautogui.write(text)
    return f"Typed: {text}"

def tool_time():
    return "The time is " + datetime.datetime.now().strftime("%H:%M:%S")

def tool_weather(city):
    return f"Weather in {city} is currently unavailable."

# === Main Loop ===
print("=== Jarvis is running with OpenRouter DeepSeek (Clean Speech Mode) ===")
print("Speak commands like:\n- 'What time is it?'\n- 'Weather in Dubai'\n- 'Open youtube.com'")

while True:
    try:
        user = listen("en-US")
        if not user:
            continue

        if user.lower().startswith("open "):
            site = user[5:].strip()
            reply = tool_open_url(site)
        elif user.lower().startswith("weather in "):
            city = user.split("in", 1)[1].strip()
            reply = tool_weather(city)
        elif user.lower().startswith("type "):
            txt = user[5:].strip()
            reply = tool_type(txt)
        elif "time" in user.lower():
            reply = tool_time()
        else:
            reply = chat(user)

        reply = clean_text(reply)
        print(f"Jarvis: {reply}")
        speak(reply)

    except KeyboardInterrupt:
        print("\nGoodbye!")
        break
    except Exception as e:
        print(f"[Error] {e}")
